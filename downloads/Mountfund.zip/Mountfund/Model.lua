-- Integer-copper budgeting, input validation, and deadline schedule calculations.
local _, ns = ...
local Model = {}
ns.Model = Model

Model.MAX_LEVEL = 60
Model.MAX_COPPER = 1000000000000
Model.CURVES = {
    [0]={name="Income-based",description="Estimate rising earnings with a level-scaled savings curve; actual income varies."},
    [1]={name="Steady saving",description="Add the same amount throughout the goal."},
    [2]={name="Save more later",description="Start gently and increase saving toward the deadline."},
}

function Model.MigrateCurve(goal)
    if goal.curve==3 or goal.curve==4 then goal.curve=2 end
end

function Model.IsTimeGoal(goal)
    return goal.goalType=="date" or goal.goalType=="played"
end

function Model.ScheduleFraction(goal, level, now, played)
    local start,finish,current
    if goal.goalType=="date" then
        start,finish,current=goal.startTime or 0,goal.deadlineTime or 0,now or ns.Now()
    elseif goal.goalType=="played" then
        start=goal.startPlayed or 0; finish=start+(goal.durationSeconds or 0); current=played or ns.GetPlayedSeconds()
    else
        start,finish,current=goal.startLevel or 1,goal.targetLevel,level
    end
    if finish<=start then return current>=finish and 1 or 0 end
    return math.max(0,math.min(1,(current-start)/(finish-start)))
end

function Model.Priority(goal,level)
    return 1-Model.ScheduleFraction(goal,level or ns.GetPlayerLevel())
end

local function integer(value, minimum, maximum)
    return type(value) == "number" and value == math.floor(value)
        and value >= minimum and value <= maximum
end

Model.IsInteger = integer

-- Validate every persisted expense, including rows on simple training goals.
-- Trainer quotes may lack a key until they are normalized from their map key.
function Model.ValidateExpense(expense, requireKey)
    if type(expense) ~= "table"
        or (requireKey ~= false and (type(expense.key) ~= "string" or expense.key == ""))
        or type(expense.name) ~= "string" or not expense.name:match("%S")
        or not integer(expense.level, 1, Model.MAX_LEVEL)
        or (expense.copper ~= nil and not integer(expense.copper, 0, Model.MAX_COPPER))
        or (expense.spellID ~= nil and not integer(expense.spellID, 1, Model.MAX_COPPER))
        or (expense.rank ~= nil and type(expense.rank) ~= "string")
        or (expense.source ~= nil and type(expense.source) ~= "string") then
        return false
    end
    for _, field in ipairs({"selected", "paid", "eligible"}) do
        if expense[field] ~= nil and type(expense[field]) ~= "boolean" then return false end
    end
    return true
end

function Model.ParseCoins(gold, silver, copper)
    local parts = { gold, silver, copper }
    for i = 1, 3 do
        local text = tostring(parts[i] or ""):match("^%s*(.-)%s*$")
        if text == "" then text = "0" end
        if not text:match("^%d+$") then return nil, "Enter whole, non-negative coin amounts." end
        parts[i] = tonumber(text)
        local maximum = i == 1 and Model.MAX_COPPER / 10000 or 99
        if not integer(parts[i], 0, maximum) then
            return nil, i == 1 and "Gold amount is too large." or "Silver and copper must be from 0 to 99."
        end
    end
    local amount = parts[1] * 10000 + parts[2] * 100 + parts[3]
    if amount > Model.MAX_COPPER then return nil, "Amount is too large." end
    return amount
end

function Model.SplitCoins(amount)
    amount = math.max(0, math.floor(amount or 0))
    return math.floor(amount / 10000), math.floor(amount / 100) % 100, amount % 100
end

function Model.FormatCoins(amount)
    local gold, silver, copper = Model.SplitCoins(amount)
    return string.format("%dg %ds %dc", gold, silver, copper)
end

-- Icon input never invalidates an otherwise valid saved goal. Drop only bad artwork.
function Model.NormalizeIcon(icon)
    if integer(icon,1,2147483647) then return icon end
    if type(icon)~="string" or #icon>240 then return nil end
    local normalized=icon:gsub("/","\\")
    if ns.ADDON_ICON and normalized:lower()==ns.ADDON_ICON:lower() then return ns.ADDON_ICON end
    local name=normalized:match("^[Ii][Nn][Tt][Ee][Rr][Ff][Aa][Cc][Ee]\\[Ii][Cc][Oo][Nn][Ss]\\([%w_%-]+)$")
    if name then return "Interface\\Icons\\" .. name end
end

function Model.CopyGoal(goal)
    local result = {}
    for key, value in pairs(goal) do
        if key ~= "milestones" and key ~= "expenses" then result[key] = value end
    end
    result.icon=Model.NormalizeIcon(goal.icon)
    result.milestones, result.expenses = {}, {}
    for level, amount in pairs(goal.milestones or {}) do result.milestones[level] = amount end
    for index, expense in ipairs(goal.expenses or {}) do
        result.expenses[index] = {}
        for key, value in pairs(expense) do result.expenses[index][key] = value end
    end
    return result
end

function Model.ExpenseTotal(goal)
    local total = 0
    for _, expense in ipairs(goal.expenses or {}) do
        if expense.selected and not expense.paid and expense.source ~= "class" and expense.level <= goal.targetLevel then
            total = total + (expense.copper or 0)
        end
    end
    return total
end

function Model.ValidateGoal(goal)
    if type(goal) ~= "table" or type(goal.name) ~= "string" or not goal.name:match("%S") then
        return nil, "Give your goal a name."
    end
    if #goal.name > 60 then return nil, "Use a name of 60 characters or fewer." end
    if not integer(goal.targetLevel, 2, Model.MAX_LEVEL) then
        return nil, "Target level must be from 2 to " .. Model.MAX_LEVEL .. "."
    end
    if goal.goalType and goal.goalType~="level" and not Model.IsTimeGoal(goal) then return nil,"Choose a level, date, or play-time goal." end
    if goal.goalType=="date" and (not integer(goal.startTime,0,5000000000)
        or not integer(goal.deadlineTime,goal.startTime+1,5000000000)) then return nil,"Choose a date after this goal started." end
    if goal.goalType=="played" and (not integer(goal.startPlayed,0,Model.MAX_COPPER)
        or not integer(goal.durationSeconds,1,31536000)) then return nil,"Set play time between one second and one year." end
    if not integer(goal.targetCopper, (goal.planMode == "items" or goal.includeClassTraining) and 0 or 1, Model.MAX_COPPER) then
        return nil, "Set a positive savings amount."
    end
    if not integer(goal.curve, 0, 2) then return nil, "Choose an income-based or custom savings curve." end
    if goal.startLevel and not integer(goal.startLevel, 1, Model.MAX_LEVEL) then return nil, "Invalid start level." end
    if goal.initialCopper and not integer(goal.initialCopper, 0, Model.MAX_COPPER) then return nil, "Invalid initial investment." end
    if goal.savedCopper and not integer(goal.savedCopper, 0, Model.MAX_COPPER) then return nil, "Invalid saved balance." end
    if goal.completedAt ~= nil and not integer(goal.completedAt,0,Model.MAX_COPPER) then return nil,"Invalid completion date." end
    if goal.completedCopper ~= nil and not integer(goal.completedCopper,0,Model.MAX_COPPER) then return nil,"Invalid completion amount." end
    if goal.active ~= nil and type(goal.active) ~= "boolean" then return nil, "Invalid tracking setting." end
    if goal.nextExpenseID ~= nil and not integer(goal.nextExpenseID, 0, Model.MAX_COPPER) then
        return nil, "Invalid expense identifier."
    end
    if goal.statusIntervalBase ~= nil and not integer(goal.statusIntervalBase, 0, Model.MAX_COPPER) then
        return nil, "Invalid interval savings."
    end
    if goal.expenses ~= nil then
        if type(goal.expenses) ~= "table" then return nil, "Invalid expense plan." end
        local keys, count = {}, 0
        for index, expense in pairs(goal.expenses) do
            if not integer(index, 1, #goal.expenses) or not Model.ValidateExpense(expense)
                or keys[expense.key] then
                return nil, "Each expense needs a name, a unique key, a valid level and a whole coin amount."
            end
            keys[expense.key], count = true, count + 1
        end
        if count ~= #goal.expenses then return nil, "Invalid expense plan." end
    elseif goal.planMode == "items" then return nil, "Invalid expense plan." end
    if goal.milestones ~= nil and type(goal.milestones) ~= "table" then return nil, "Invalid milestones." end
    if goal.planMode == "items" then
        if Model.ExpenseTotal(goal) > Model.MAX_COPPER then return nil, "Total expense amount is too large." end
        return true
    end
    if type(goal.milestones) ~= "table" then return nil, "Invalid milestones." end
    if Model.IsTimeGoal(goal) then return true end
    for level, amount in pairs(goal.milestones) do
        if not integer(level, (goal.startLevel or 1) + 1, goal.targetLevel - 1)
            or not integer(amount, 0, goal.targetCopper) then
            return nil, "Milestones must fall before the target level and within the final amount."
        end
    end
    local previous = 0
    for _, point in ipairs(Model.Points(goal)) do
        if point.copper < previous then return nil, "Saved amounts must increase or stay equal as levels rise." end
        previous = point.copper
    end
    return true
end

function Model.Points(goal)
    local points = { { level = goal.startLevel or 1, copper = goal.initialCopper or 0 } }
    for level, copper in pairs(goal.milestones) do
        points[#points + 1] = { level = level, copper = copper }
    end
    points[#points + 1] = { level = goal.targetLevel, copper = goal.targetCopper }
    table.sort(points, function(a, b) return a.level < b.level end)
    return points
end

function Model.Fraction(startLevel, endLevel, level, curve)
    if endLevel <= startLevel then return level >= startLevel and 1 or 0 end
    if level <= startLevel then return 0 end
    if level >= endLevel then return 1 end
    if curve ~= 0 then return ((level - startLevel) / (endLevel - startLevel)) ^ curve end
    local earned, total = 0, 0
    for step = startLevel + 1, endLevel do
        local weight = ns.IncomeWeights and ns.IncomeWeights[step] or (step - 1) ^ 3
        total = total + weight
        if step <= level then earned = earned + weight end
    end
    return total > 0 and earned / total or 0
end

function Model.TargetAtLevel(goal, level, now, played)
    if Model.IsTimeGoal(goal) then
        local initial=math.min(goal.initialCopper or 0,goal.targetCopper)
        local fraction=Model.ScheduleFraction(goal,level,now,played)^(goal.curve==0 and 1 or goal.curve)
        return math.floor(initial+(goal.targetCopper-initial)*fraction+0.0000001)
    end
    local start = goal.startLevel or 1
    if level < start then return 0 end
    local initial = math.min(goal.initialCopper or 0, goal.targetCopper)
    if goal.planMode == "items" then
        local total, weighted = Model.ExpenseTotal(goal), 0
        for _, expense in ipairs(goal.expenses) do
            if expense.selected and not expense.paid and expense.source ~= "class"
                and expense.level <= goal.targetLevel and expense.copper then
                weighted = weighted + expense.copper * Model.Fraction(start, expense.level, level, goal.curve)
            end
        end
        if total == 0 then return 0 end
        return math.floor(initial + (total - initial) * weighted / total)
    end
    if level == start and goal.targetLevel > start then return initial end
    if level >= goal.targetLevel then return goal.targetCopper end
    local points = Model.Points(goal)
    for i = 2, #points do
        local left, right = points[i - 1], points[i]
        if level <= right.level then
            return math.floor(left.copper + (right.copper - left.copper)
                * Model.Fraction(left.level, right.level, level, goal.curve))
        end
    end
    return initial
end

function Model.IntervalSaved(goal, level, now, played)
    level=level or ns.GetPlayerLevel(); now=now or ns.Now(); played=played or ns.GetPlayedSeconds()
    local key="level:" .. level
    if goal.goalType=="date" then key="date:" .. date("%Y-%m-%d",now)
    elseif goal.goalType=="played" then
        local start=goal.startPlayed or 0
        key="played:" .. start .. ":" .. math.floor(math.max(0,played-start)/3600)
    end
    return math.min(goal.targetCopper,(goal.statusIntervalKey==key and goal.statusIntervalBase)
        or goal.savedCopper or goal.initialCopper or 0)
end

-- Rebase only the remaining schedule, keeping the original curve for ahead/behind comparisons.
function Model.AdaptiveTarget(goal, futureLevel, futureTime, futurePlayed, anchorLevel)
    local level=anchorLevel or ns.GetPlayerLevel()
    local now,played=ns.Now(),ns.GetPlayedSeconds()
    local anchorTime,anchorPlayed=now,played
    if goal.goalType=="date" then
        local parts=date("*t",now)
        anchorTime=time({year=parts.year,month=parts.month,day=parts.day,hour=0,min=0,sec=0})
    elseif goal.goalType=="played" then
        local start=goal.startPlayed or 0
        anchorPlayed=start+math.floor(math.max(0,played-start)/3600)*3600
    end
    if not Model.IsTimeGoal(goal) and futureLevel<(goal.startLevel or 1) then return Model.TargetAtLevel(goal,futureLevel) end
    local original=Model.TargetAtLevel(goal,level,anchorTime,anchorPlayed)
    local future=Model.TargetAtLevel(goal,futureLevel,futureTime,futurePlayed)
    if future<original then return future end
    local base=Model.IntervalSaved(goal,level,now,played)
    if original>=goal.targetCopper then return goal.targetCopper end
    return math.floor(base+(goal.targetCopper-base)*math.max(0,math.min(1,(future-original)/(goal.targetCopper-original)))+0.0000001)
end

-- The attained-level target measures progress so far. The next boundary is
-- the savings target to work toward while playing the current level.
function Model.LevelPlanStep(goal, level)
    local boundary=level
    if level>=(goal.startLevel or level) and level<goal.targetLevel then boundary=level+1 end
    local target=Model.AdaptiveTarget(goal,boundary,nil,nil,level)
    if level>=goal.targetLevel then
        return {target=goal.targetCopper,addition=math.max(0,goal.targetCopper-Model.IntervalSaved(goal,level))}
    end
    return {target=target,addition=math.max(0,target-Model.AdaptiveTarget(goal,level,nil,nil,level)),
        byLevel=boundary>level and boundary or nil}
end

function Model.GoalProgress(goal, level)
    local saved = math.min(goal.savedCopper or 0, goal.targetCopper)
    local expected = Model.TargetAtLevel(goal, level)
    return { saved = saved, expected = expected, target = goal.targetCopper,
        ahead = math.max(0, saved - expected), behind = math.max(0, expected - saved),
        percent = goal.targetCopper > 0 and math.min(100, saved / goal.targetCopper * 100) or 100 }
end

-- Goal allocations have priority; class training belongs to the shared spending
-- pool. Wallet targets seed new allocations, while income is split independently.
function Model.WalletSplit(balance, trainingDue)
    balance = integer(balance, 0, Model.MAX_COPPER) and balance or 0
    if trainingDue == nil then trainingDue = 0 end
    trainingDue = integer(trainingDue, 0, Model.MAX_COPPER) and trainingDue or balance
    local goalLimit = math.floor(balance * 3 / 4)
    local spendingTarget = balance - goalLimit
    local trainingFunded = math.min(spendingTarget, trainingDue)
    return {balance=balance, trainingDue=trainingDue, trainingFunded=trainingFunded,
        trainingShortfall=trainingDue-trainingFunded, goalLimit=goalLimit,
        spendingTarget=spendingTarget}
end

function Model.Reconcile(goals, balance, trainingDue)
    local split = Model.WalletSplit(balance, trainingDue)
    local left = split.balance
    for _, goal in ipairs(goals) do
        if goal.active then
            goal.savedCopper = math.min(goal.savedCopper or 0, goal.targetCopper, left)
            left = left - goal.savedCopper
        else goal.savedCopper = 0 end
    end
    return split.balance - left
end

function Model.Budget(goals, level, balance, trainingDue)
    local split = Model.WalletSplit(balance, trainingDue)
    balance, trainingDue = split.balance, split.trainingDue
    local saved, expected = 0, 0
    for _, goal in ipairs(goals) do
        if goal.active then
            saved = saved + math.min(goal.savedCopper or 0, goal.targetCopper)
            expected = expected + Model.TargetAtLevel(goal, level)
        end
    end
    saved = math.min(balance, saved)
    local spendingBalance = balance - saved
    local trainingFunded = math.min(spendingBalance, trainingDue)
    return { balance = balance, saved = saved, expected = expected,
        ahead = math.max(0, saved - expected), behind = math.max(0, expected - saved),
        trainingDue = trainingDue, trainingFunded = trainingFunded,
        trainingShortfall = trainingDue - trainingFunded, reserved = saved + trainingFunded,
        spendingTarget = split.spendingTarget, spendingBalance = spendingBalance,
        spendingAvailable = spendingBalance - trainingFunded, goalLimit = split.goalLimit }
end

local function allocateGoals(goals, amount)
    local left = amount
    for _, goal in ipairs(goals) do
        if goal.active then
            local addition = math.min(left, math.max(0, goal.targetCopper - (goal.savedCopper or 0)))
            goal.savedCopper = (goal.savedCopper or 0) + addition
            left = left - addition
        end
    end
end

-- Explicit goal edits may seed the unallocated portion of the wallet target.
function Model.FundGoals(goals, amount, balance, trainingDue, level)
    local split = Model.WalletSplit(balance, trainingDue)
    local saved = Model.Reconcile(goals, split.balance, split.trainingDue)
    amount = integer(amount, 0, Model.MAX_COPPER) and amount or 0
    allocateGoals(goals, math.min(amount, math.max(0, split.goalLimit - saved)))
end

-- Carry quarter-copper units so repeated small loots receive the same split as
-- one combined payment. Callers keep real and preview remainders separate.
function Model.FundIncome(goals, amount, balance, trainingDue, remainder)
    local split = Model.WalletSplit(balance, trainingDue)
    local saved = Model.Reconcile(goals, split.balance, split.trainingDue)
    amount = integer(amount, 0, Model.MAX_COPPER) and math.min(amount, split.balance) or 0
    remainder = integer(remainder, 0, 3) and remainder or 0
    local quarters = amount * 3 + remainder
    allocateGoals(goals, math.min(math.floor(quarters / 4), split.balance - saved))
    return quarters % 4
end

function Model.InitialInvestment(balance, trainingDue, allocated, target)
    local split = Model.WalletSplit(balance, trainingDue)
    allocated = integer(allocated, 0, Model.MAX_COPPER) and allocated or split.goalLimit
    target = integer(target, 0, Model.MAX_COPPER) and target or 0
    return math.max(0, math.min(split.goalLimit - allocated, target))
end

function Model.Purchase(goals, level, balance, cost, trainingDue, plannedTraining)
    local budget = Model.Budget(goals, level, balance, trainingDue)
    budget.cost, budget.remaining, budget.affordable = cost, balance - cost, cost <= balance
    local protected = budget.reserved
    if plannedTraining then protected = protected - math.min(cost, budget.trainingFunded) end
    budget.warning = cost > 0 and budget.remaining < protected
    budget.afterSaved = math.min(budget.saved, math.max(0, budget.remaining))
    budget.savingsUsed = budget.saved - budget.afterSaved
    budget.afterShortfall = math.max(0, protected - budget.remaining)
    return budget
end
