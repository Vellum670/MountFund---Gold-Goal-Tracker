# Changelog

Newest releases appear first. Release notes begin after version **0.3.1**.

## Unreleased

No changes queued yet.

## 0.4.16 - 2026-10-14

- Show the savings target to reach before the next level under Goal for this
  level, including its scheduled addition and By level checkpoint. Curve
  changes now show their effect immediately at the goal's starting level.
- Place the current target amount directly beside its label. Clarify that
  curve choices change planned targets, while actual saved money stays intact.
- Keep the README focused on player installation and usage, removing developer
  commands, testing and packaging instructions, and implementation details.

## 0.4.15 - 2026-10-14

- Keep an itemized mount's allowance separate from its observed riding fee.
  The first known quote preserves the entered combined budget; later fee
  updates no longer erase or change the mount allowance.
- Allow unchanged spending warnings to be confirmed once after background
  refreshes, while rechecking price, affordability, and protected spending.
- Give manual expenses due-level and expense-selection tooltips. Explain that
  disabling goal tracking releases its allocation and restarting funds from zero.
- Add a saved collapse/expand control for gold tips and shrink the main window
  when collapsed. Show aggregate progress only when multiple goals exist.
- Offer Income-based, Steady saving, and Save more later curves. Migrate Light
  start and Late push goals to Save more later while retaining their saved
  allocations, amounts, deadlines, and valid checkpoints.

## 0.4.14 - 2026-10-14

- Use "sellable" in the Wetlands gold-making tip for clearer wording.

## 0.4.13 - 2026-10-14

- Advance to the next gold-making tip in your level bracket each time the
  Gold Envelope window reopens. Page changes and progress updates keep the
  current tip, and the arrows still allow manual browsing.

## 0.4.12 - 2026-10-14

- Add gold-making tips at the bottom of the main page, matched to your current
  level bracket, with a separate set of fifteen ideas at level 60.
- Browse tips using compact arrows, keeping farming locations, requirements,
  and selling context. Tips also follow test-level previews.

## 0.4.11 - 2026-10-14

- Save pending goal and expense fields before reload or logout, even when the
  cursor is still in a field. Preserve unfinished input as a draft.
- Save an active toast-position adjustment before logout. Test-wallet goals
  remain temporary and never replace real saved goals.

## 0.4.10 - 2026-10-14

- Even out gold, silver, and copper input spacing, including the native field
  borders, and center each coin icon beside its field.

## 0.4.9 - 2026-10-14

- Add a Delete button beside each goal in the Goals list, and keep the main
  page's Delete goal button inside its visible bounds.
- Remove a deleted goal's pending drafts so autosave cannot restore it, while
  preserving unfinished fields for remaining goals.
- Keep actual gold and trainer data intact. Goal deletion during gold testing
  affects only the session's simulated goals.

## 0.4.8 - 2026-10-14

- Rename the expense button and page to **Additional Expenses**.
- Add a small delete button to manually added expenses. Deletion saves
  immediately and clears the expense's editor so it does not reappear on close.
- Keep class, profession, riding, and the original goal budget protected from
  deletion. Training retains its include/exclude controls.

## 0.4.7 - 2026-10-14

- Hovering a toast resets its six-second dismissal timer and holds it open;
  moving the cursor away resumes the countdown. Hover restores a fading toast
  to full visibility without restarting its progress-bar animation.
- Keep normal toasts click-through and retain combat deferral while hovering.

## 0.4.6 - 2026-10-14

- Show the goal-progress toast once on character login with a "Welcome back!"
  message. Zoning, instance loading, and UI reloads do not trigger it.
- Use the existing notification setting for login and level-up toasts. Login
  progress requires an active goal and waits until combat ends when necessary.

## 0.4.5 - 2026-10-14

- Add a gold arrow and hover hint to the goal-type button so players can see
  that clicking cycles between level, calendar date, and play time.

## 0.4.4 - 2026-10-14

- Match the Class training button's width and left edge to the expense button
  below it.

## 0.4.3 - 2026-10-14

- Move each level's cumulative savings goal to the right column of the plan.
  The middle column shows the planned addition and a minus-expenses line.
- Include selected, unpaid class training, profession, riding, and manual
  expenses at their due levels. Hover the expense line for individual costs;
  unknown prices are flagged. Viewing the plan does not deduct any money.

## 0.4.2 - 2026-10-14

- Added **Goal for this level** to the main page with the selected goal's
  planned total and scheduled addition for the current level.
- Use **Goal for now** for calendar and play-time goals, and show the upcoming
  training budget for training-only goals. Keep the main window at 400 × 450.

## 0.4.1 - 2026-10-14

- Make every training ability icon selectable, including abilities with unmet
  prerequisites and those with no later upgrades. Only excluded icons turn grey.
- Show the next rank's level after your current level instead of "Now". Keep
  abilities without later upgrades visible as "Max", sorted after future ranks.
- Recognize learned higher ranks when checking an ability's quest or talent
  prerequisite, fixing Sunder Armor eligibility and its training budget.
- Keep observed unpaid older ranks in expense calculations while showing the
  upcoming upgrade in the icon and tooltip.

## 0.4.0 - 2026-10-14

- Added calendar-date and character-play-time goals alongside level goals.
  Calendar deadlines advance offline; play-time goals count logged-in time.
- Moved goal lists, presets, training, expenses, plans, and settings into pages
  of the same window, with Back navigation and smaller layouts for short pages.
- Shrink short savings plans and expense grids to fit their rows, and tighten
  preset and settings pages. Time plans omit the empty training column heading.
- Added descriptive savings-curve names and silent editing. Removed save
  confirmations and clarified the protected-spending setting.
- Update training icons for the current class and level, showing and sorting
  by each ability's next unlearned rank. Fully learned abilities disappear.
- Show observed unpaid training as the next upgrade before a later rank, then
  advance its icon and level when it is learned.
- Clear stale unknown-price tooltip notices when a reused icon has known costs.
- Apply quest and talent prerequisites to every trainer rank of an ability.
- Center the level-up toast near the top of the screen by default. Settings
  lets you drag its preview; Escape or the move button saves the position.
  Saved positions adapt to resolution changes.
- Escape saves fields and settings before closing any page. Incomplete input
  is retained separately so it can be resumed without replacing valid goals.

## 0.3.6 - 2026-10-14

- Added `/ge testgold` to simulate a wallet and experiment with goal funding,
  spending, training budgets, and toast progress using session-only copies.
- Require a password at the end of all gold, level, and toast test commands.
- Retain the test commands in final builds. Overrides reset on reload, logout,
  or character change; simulated goal edits never overwrite real saved goals.
- Keep real purchases and actual earnings independent of simulated values.

## 0.3.5 - 2026-10-14

- Added temporary `/ge testlevel 1-60` to simulate a character level inside
  Gold Envelope and preview its goal progress, training costs, and level-up toast.
- Use `/ge testlevel reset` to return to your real level. The override also
  resets on reload, logout, or character change and is never saved.
- Show the active test level in the goal window. The command does not change
  your character's actual level, money, or existing saved progress.

## 0.3.4 - 2026-10-14

- Fixed overlapping borders on training ability icons. Each icon now has a
  consistent, thin gold or grey frame, with hover highlighting inside it.

## 0.3.3 - 2026-10-14

- Added a quiet level-up toast with actual goal savings, an animated progress
  bar, and how far ahead or behind you are. Fully funded goals get a celebration.
- Show up to two goals by nearest deadline and fade away after six seconds.
  The toast is silent, lets clicks pass through, and waits until combat ends.
- Added `/ge toasts` to turn level-up notifications on or off.
- Added temporary `/ge testtoast` for in-game preview without leveling or
  changing goal progress. An example appears if you have no active goal.

## 0.3.2 - 2026-10-14

- Replaced training checklists with an eight-column grid of clickable ability
  icons. Excluded abilities appear grey, and hovering shows the full spell tooltip.
- Use one icon per ability; choosing it includes or excludes all its ranks.
- Added a Class training button to the goal editor with a separate ability
  window. New goals include eligible, unlearned training by default.
- Save fields automatically when focus leaves them and save icon selections
  immediately. Removed the Save goal and Apply choices steps.
- Handle the initial savings allocation automatically in the background; goal
  progress shows how far ahead or behind you are.
- Keep the goal first in the expense window and condense the main window.
- Protect the shared training budget across goals and retain ability exclusions
  when new trainer ranks appear.
- Include this changelog in the addon download.
